/*
	Pink Balloon - LudiPQ Bonus stage NPC
*/

function start() {
    cm.sendNext("This is the #rBonus Stage#k. Breaking the boxes will give you some rare equips and use items - you only have a minute, so what're you waiting for? Go break the boxes!");
}

function action(mode, type, selection) {
                
}