/*
	Koscu - Leafre : Leafre (240000000)
*/

function start() {
    cm.sendStorage();
                
}