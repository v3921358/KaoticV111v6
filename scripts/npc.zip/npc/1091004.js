/*
Dondlass - Nautilus' Port
*/

function start() {
    cm.sendStorage();
                
}