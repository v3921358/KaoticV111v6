/*
	Ahmad - The Burning Road: Ariant(260000000)
*/

function start() {
    cm.sendStorage();
                
}