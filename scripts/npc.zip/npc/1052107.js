function start() {
	cm.getMap().killMonster(5090000);
	            
}

function action(mode, type, selection) {
}	