function start() {
	cm.getMap().killMonster(5090001);
	            
}

function action(mode, type, selection) {
}	