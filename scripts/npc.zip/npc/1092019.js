/*
Lord Jonathan - Nautilus' Port
*/

function start() {
    cm.sendOk("Who are you talking to me? If you're just bored, go bother somebody else.");
}

function action(mode, type, selection) {
                
}
