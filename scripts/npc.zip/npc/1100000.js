function start() {
    cm.sendStorage();
                
}