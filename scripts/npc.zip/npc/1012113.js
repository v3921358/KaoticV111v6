
function action(mode, type, selection) {
	cm.warp(100000200);
	            
}