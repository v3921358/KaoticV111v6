function start() {
	cm.sendOk("You don't have anything for the Clothes Collector.");
	            
}