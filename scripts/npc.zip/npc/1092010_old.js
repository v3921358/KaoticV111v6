/*
Jack - Nautilus' Port
*/

function start() {
    cm.sendOk("(Scratch scratch...)");
}

function action(mode, type, selection) {
                
}
