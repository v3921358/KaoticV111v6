/* 
 *   NPC   : Kenta
 *   Map   : Aquariun - Zoo
 */

function start() {
	            
}

function action(mode, type, selection) {
                
}