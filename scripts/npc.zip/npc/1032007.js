/* Author: Xterminator
	NPC Name: 		Joel
	Map(s): 		Victoria Road : Ellinia Station (101000300)
	Description: 		Ellinia Ticketing Usher
*/
var status = -1;

function action(mode, type, selection) {
    cm.sendOk("Hope you enjoy your stay at Ellinia.");
                
}