/* Author: aaroncsn(MapleSea Like)
	NPC Name: 		Kidan
	Map(s): 		Queens Road: Temple of the Knight (130000100)
	Description: 		Welcoming
*/

function start(){
	cm.sendOk("Welcome to the Hall of Knights.");
	            
}