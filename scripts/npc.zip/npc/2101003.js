
/* 	Ardin
	Ariant	
*/


function start() {
    cm.sendNext ("Hey hey, don't try to start trouble with anyone. I want nothing to do with you.");
}

function action() {
    cm.dispose()
}