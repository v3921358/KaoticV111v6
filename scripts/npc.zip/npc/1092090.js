/**
	Tangyoon - Nautilus Cook
**/

function start() {
    cm.removeAll(4031847);
    cm.removeAll(4031848);
    cm.removeAll(4031849);
    cm.gainItem(4031850, 1);
    cm.warp(120000100, 0);
                
}