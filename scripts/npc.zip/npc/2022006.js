function action(mode, type, selection) {
    cm.sendNext("Haha! FOOLS! I have betrayed you and have unsealed Rex, the Hoblin King!");
                
}