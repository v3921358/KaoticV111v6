/* 	Sejan
	Ariant
*/


function start() {
    cm.sendNext("The light and dark always coexist...");
}

function action() {
    cm.dispose()
}